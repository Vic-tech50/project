
    

    <body class="nav-fixed">
        
        <div id="layoutSidenav">
           
            <div id="layoutSidenav_content">
                <main>
                    <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
                        <div class="container">
                            <div class="page-header-content pt-4">
                                <div class="row align-items-center justify-content-between">
                                    <div class="col-auto mt-4">
                                        <h1 class="page-header-title">
                                            <div class="page-header-icon"><i data-feather="edit-3"></i></div>
                                           Registration - New Member
                                        </h1>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>


                    <!-- Main page content-->
                    <div class="container mt-n10">

                                                     <?php 
                    if($this->session->flashdata('mess')){
                      echo "<div class = 'alert alert-danger'>".' <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'. $this->session->flashdata('mess'). "</div>";
                    }
                ?> 
                        
                            <div class="col-lg-6">
                                <!-- Default Bootstrap Form Controls-->
                                <div id="default">
                                    <div class="card mb-4">
                                        <div class="card-header">Fill in the forms</div>
                                        <div class="card-body">
                                            <!-- Component Preview-->
                                            <div class="sbp-preview">
                                                <div class="sbp-preview-content">
                                                    <!-- <form method="post" action="<?php //echo site_url('welcome/signup_verify') ?>"> -->

                                                         <?php echo form_open('welcome/signup_verify'); ?>
                                                        <div class="form-group">
                                                            <label>Full Name</label>
                                                            <input class="form-control" name="name" type="text"  required />
                                                        </div>
                                                         <div class="form-group">
                                                            <label>Email address</label>
                                                            <input class="form-control" name="email" type="email"  required />
                                                        </div>
                                                         <div class="form-group">
                                                            <label>Phone</label>
                                                            <input class="form-control" name="phone"  type="text"  required />
                                                        </div>
                                                         <div class="form-group">
                                                            <label >Course Of Study</label>
                                                            <input class="form-control" name = "course" type="text"  required />
                                                        </div>
                                                         <div class="form-group">
                                                             <label class="radio-inline">
                                                              <input type="radio" name="radio" value="male">Male
                                                            </label>
                                                            <label class="radio-inline">
                                                              <input type="radio" name="radio" value="female">Female
                                                            </label>
                                                        </div>
                                                         <div class="form-group">
                                                            <label>Username</label>
                                                            <input class="form-control" name="username" type="text"  required />
                                                        </div>
                                                       <div class="form-group">
                                                            <label>Password</label>
                                                            <input class="form-control" name="pass" type="password"  required />
                                                        </div>
                                                       

                                                        <input type="submit" value="submit">
                                                       
                                                      <!--  <button class="btn btn-primary">Submit</button> -->
                                                       
                                                    </form>
                                                </div>  
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </main>
               
