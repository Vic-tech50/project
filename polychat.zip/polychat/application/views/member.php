  <div id="layoutSidenav_content">
                <main>
                    <!-- Main page content-->
                    <div class="container mt-5">
                        <!-- Custom page header alternative example-->
                        <div class="d-flex justify-content-between align-items-sm-center flex-column flex-sm-row mb-4">
                           
                            <!-- Date range picker example button-->
                            <button class="btn btn-white btn-sm line-height-normal p-3" id="reportrange">
                                <i class="mr-2 text-primary" data-feather="calendar"></i>
                                <span></span>
                                <i class="ml-1" data-feather="chevron-down"></i>
                            </button>
                        </div>
                        <!-- Illustration dashboard card example-->
                        <div class="card card-waves mb-4 mt-5">
                            <div class="card-body p-5">
                                <div class="row align-items-center justify-content-between">
                                    <div class="col">
                                        <h2 class="text-primary">Welcome back, your dashboard is ready!</h2>
                                        <p class="text-gray-700">Great job, your affiliate dashboard is ready to go! You can view sales, generate links, prepare coupons, and download affiliate reports using this dashboard.</p>
                                        <a class="btn btn-primary btn-sm px-3 py-2" href="<?php echo site_url('welcome/post_news') ?>">
                                            Add Questions
                                            <i class="ml-1" data-feather="arrow-right"></i>
                                        </a>
                                    </div>
                                    <div class="col d-none d-lg-block mt-xxl-n4"><img class="img-fluid px-xl-4 mt-xxl-n5" src="<?php echo base_url() ?>assets/img/freepik/statistics-pana.svg" /></div>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </main>
            </div>