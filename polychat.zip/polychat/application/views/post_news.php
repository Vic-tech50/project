<div class="container">
	<br><br>
	<div>
		
			<h2><b>Create Post</b></h2>
		<div class="jumbotron">	
		<?php echo form_open('welcome/post'); ?>

		<?php 
                    if($this->session->flashdata('message')){
                      echo "<div class = 'alert alert-primary'>".' <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'. $this->session->flashdata('message'). "</div>";
                    }
                ?>
 <div class="form-group">
    <label for="inputAddress">Title</label>
    <input type="text" class="form-control" name="header">
  </div>


			<div class="form-group">
  <label for="comment">Comment</label>
  <textarea class="form-control" rows="5" id="comment" name="news" required></textarea>
</div>
			
			<input type="submit" name="submit" value="Post" class="btn btn-primary">
		</form>
	</div>
	
	</div>
</div>

<br><br><br>