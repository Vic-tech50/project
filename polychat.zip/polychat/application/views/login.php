
    

    <body class="nav-fixed">
        
        <div id="layoutSidenav">
           
            <div id="layoutSidenav_content">
                <main style="width: 40%; margin: auto; margin-top: 100px;">
                   
                    <!-- Main page content-->
                    <div class="container mt-n10">
                        
                                <div id="default">
                                    <div class="card mb-4">
                                        <div class="card-header">Fill in the forms</div>
                                        <div class="card-body">
                                            <!-- Component Preview-->
                                            <div class="sbp-preview">
                                                <div class="sbp-preview-content">
                                                    <form action="<?php echo site_url('welcome/auth') ?>"  method="post" >
                                                        
                                                         <div class="form-group">
                                                            <label>Username</label>
                                                             <input class="form-control" name="username" type="text"  required />
                                                        </div>
                                                       <div class="form-group">
                                                            <label>Password</label>
                                                            <input class="form-control" name="pass" type="password"  required />
                                                        </div>
                                                      
                                                       
                                                       <button class="btn btn-primary">Login</button>
                                                       
                                                    </form>
                                                </div>  
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            
                    </div>
                </main>
               
