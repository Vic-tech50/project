<div class="container">
	<div class="jumbotron">

	
           <?php 
                    if($this->session->flashdata('mess')){
                      echo "<div class = 'w3-container w3-blue'>".' <span onclick="this.parentElement.style.display="none"" class="w3-closebtn">x</span> '. $this->session->flashdata('mess'). "</div>";
                    }
                ?>
              
<h2>STUDENT QUESTION</h2>
<table class="table table-striped w3-hoverable">
  <thead class="thead-dark w3-round-large">
    <tr>
      
      <th scope="col">Title</th>
      <th scope="col">Post</th>
      <th scope="col">Student Username</th>
      <th scope="col">Date</th>
       
      
    </tr>
  </thead>
  <tbody>
  <?php 

foreach ($allquestion as $key => $gotten_file) {
	?>
		<tr>
			<td><?php echo $gotten_file['title']; ?></td>
  		<td><?php echo $gotten_file['post']; ?></td>
  		<td><?php echo $gotten_file['username']; ?></td>
  		<td><?php echo $gotten_file['date']; ?></td>
  	
  	
  		
  	</tr>
<?php
} 




?>
  
  </tbody>
</table>



		
	</div>
</div>