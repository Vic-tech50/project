<div class="container">
	<br><br>
	<div>
		
			<h2><b>Create Post</b></h2>
		<div class="jumbotron">	
	
		<?php 

		if($in > $amt['amt'] - $total['amt']){
			echo "<div class = 'alert alert-primary'>".' <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'. 'Insufficient Fund'. "</div>";
		}else{
                    if($this->session->flashdata('message')){
                      echo "<div class = 'alert alert-primary'>".' <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'. $this->session->flashdata('message'). "</div>";
                    }
                  }
                ?>

                <?php if($amt['amt'] == 0 or $amt['amt'] == null or $amt['amt'] - $total['amt'] == 0){ ?>

                	<h1>No Money, Pls add up</h1>
                	<?php 
                }else{
                ?>
                
                		<?php 
			if($in > $amt['amt'] - $total['amt']){
		?>	
			<form action="#"  accept-charset="utf-8">
<?php
}else{ ?>
		 <form action="<?php echo site_url('welcome/send'); ?>" method="post" accept-charset="utf-8">


 <?php  }?>
 <div class="form-group">
    <label for="inputAddress">Username</label>
    <input type="text" class="form-control" name="user">
  </div>


			<div class="form-group">
  <label for="comment">Amount</label>
  <input type="number" class="form-control" rows="5" id="comment" name="amt" required>
</div>
			
			<input type="submit" name="submit" value="send" class="btn btn-primary">
		</form>
	</div>
	
	</div>
</div>
<?php }?>



<br><br><br>