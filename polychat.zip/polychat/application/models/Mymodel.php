<?php 
 
class Mymodel extends CI_Model
{
	function insertdata()
		{
$datestring = '%Y-%m-%d - %h:%i %a';
$time = time();
$date = mdate($datestring,$time);


	$user_data = array(
		'fullname' => $this->input->post('name'),
		'email' => $this->input->post('email'),
		'phone' => $this->input->post('phone'),
		'course' => $this->input->post('course'),
		'gender' => $this->input->post('radio'),
		'username' => $this->input->post('username'),
		'password' =>$this->input->post('pass'),
		

		'status' =>'2',
		
		'date' => $date
		
	);
	if($this->db->insert('student_table',$user_data)){
		return true;
	}else{
		return false;
	}
		}




function validate_login($username,$password){
    $this->db->where('username',$username);
    $this->db->where('password',$password);
    $result = $this->db->get('student_table',1);
    return $result;
  }

  	function insert_into_blog()
{
$datestring = '%Y-%m-%d - %h:%i %a';
$time = time();
$date = mdate($datestring,$time);
$ques = array(
		'title' => $this->input->post('header'),
		'post' => $this->input->post('news'),
		'username' => $this->session->userdata('username'),
		'date' => $date
		
	);
	if($this->db->insert('question_table',$ques)){
		return true;
	}else{
		return false;
	}
		}


  	function send_money()
{
$datestring = '%Y-%m-%d - %h:%i %a';
$time = time();
$date = mdate($datestring,$time);
$amt = array(
		'username' => $this->input->post('user'),
		'amt' => $this->input->post('amt'),
		'name' => $this->session->userdata('username'),
		'date' => $date
		
	);
	if($this->db->insert('send_table',$amt)){
		return true;
	}else{
		return false;
	}
		}		





function questions()
{
	$query = $this->db->get_where('question_table',array('username' => $this->session->userdata('username')));
	return $query->result_array();

}

function amount()
{
$this->db->select_sum('amt');
	$query = $this->db->get_where('send_table',array('username' => $this->session->userdata('username')));
	return $query->row_array();
}

function total()
{
$this->db->select_sum('amt');
	$query = $this->db->get_where('send_table',array('name' => $this->session->userdata('username')));
	return $query->row_array();
}

function insert_into_news()
{
$datestring = '%Y-%m-%d - %h:%i %a';
$time = time();
$date = mdate($datestring,$time);
$news = array(
		'title' => $this->input->post('header'),
		'info' => $this->input->post('news'),
		'pics' => $this->upload->data('file_name'),
		'date' => $date
		
	);
	if($this->db->insert('blog',$news)){
		return true;
	}else{
		return false;
	}
		}

	function userdata()
{
	$this->db->order_by('date', 'DESC');
  $query = $this->db->get('question_table');
  return $query->result_array();
}	

	function news()
{
	$this->db->order_by('date', 'DESC');
  $query = $this->db->get('blog');
  return $query->result_array();
}	























}