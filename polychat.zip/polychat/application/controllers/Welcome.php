<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('header');
		$this->load->view('body');
		$this->load->view('foot');
	}


	public function register()
	{
		$this->load->view('header');
		$this->load->view('register');
		$this->load->view('foot');
	}

	public function login() 
	{
		$this->load->view('header');
		$this->load->view('login');
		$this->load->view('foot');
	}


public function member()
	{
		if($this->session->userdata('status')==='2'){
      	 
      	 
		$this->load->view('head');
          $this->load->view('member');
          $this->load->view('foot');
      }else{
          echo "Access Denied";
      }
	}


public function admin()
	{
		if($this->session->userdata('status')==='1'){
      	 
      	  $this->load->view('head');
          $this->load->view('admin');
          $this->load->view('foot');
      }else{
          echo "Access Denied";
      }
	}



	public function post_news()
	{
		$this->load->view('head');
		$this->load->view('post_news');
		$this->load->view('foot');
	}

	public function read_news()
	{
		$data['news'] = $this->mymodel->news();
		$this->load->view('head',$data);
		$this->load->view('read_news');
		$this->load->view('foot');
	}


	public function all_questions()
	{
		$data['allquestion'] = $this->mymodel->userdata();
		$this->load->view('head',$data);
		$this->load->view('allquestion');
		$this->load->view('foot');
	}

	


	public function my_questions()
	{
		$data['quests'] = $this->mymodel->questions();
		$this->load->view('head',$data);
		$this->load->view('all_quests');
		$this->load->view('foot');
	}

	

	function post(){

  if($this->input->post('header'))

			
		{
			
			if($this->mymodel->insert_into_blog())
			{

				$this->session->set_flashdata('message', 'Posted Successfully');
			}else
			{
				$this->session->set_flashdata('message', 'Not Posted, Try again');

			}
			redirect('welcome/post_news');
	}


}




function add_news()

{
		$config['upload_path']          = './img/';
             $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 800000;
                $config['max_width']            = 5000;
                $config['max_height']           = 5000;

                $this->upload->initialize($config);

  if($this->upload->do_upload('img'))

			
		{
			
			if($this->mymodel->insert_into_news())
			{

				$this->session->set_flashdata('message', 'Posted Successfully');
			}else
			{
				$this->session->set_flashdata('message', 'Not Posted, Try again');

			}



			redirect('welcome/admin');
		}
	
}


		public function signup_verify()
	{ 

                	   if($this->input->post('name')){

    		if($this->mymodel->insertdata()){
    				$this->session->set_flashdata('mess', "signup successful");
    				redirect('welcome/login');
			}else{
				
				$this->session->set_flashdata('mess', "Wrong Input, try again");
				redirect('welcome/register');
			}
			
    	}
               
                
               
		
	}



    function auth(){
    $username    = $this->input->post('username',TRUE);
    $password = $this->input->post('pass',TRUE);
    $validate = $this->mymodel->validate_login($username,$password);
    if($validate->num_rows() > 0){
        $data  = $validate->row_array();
        $username  = $data['username'];
        $phone  = $data['phone'];
        $email = $data['email'];
        $level = $data['status'];
         $code  = $data['verify_code'];
        //$password  = $data['password'];
        /*$age = $data['age'];
        $user = $data['username'];*/
        $date = $data['date'];
        $sesdata = array(
            'username'  => $username,
            'email'     => $email,
            'status'     => $level,
           // 'verify_code'  => $code,
            'phone'     => $phone,
           'password'     => $password,
            'date'     => $date,
            'logged_in' => TRUE  
        );
        $this->session->set_userdata($sesdata);
        // access login for admin
        if($level === '1'){
            redirect('welcome/admin');
 
        // access login for staff
        }elseif($level === '2'){
            redirect('welcome/member');
 
        // access login for author
        }else{
          
            echo '<center><h3>Account not found! If you need to signup click below</h3>
            <p><i class = "fa  fa-hand-o-down" style = "color: blue; font-size: 20px"></i></p>
                 <a href="./register"><button class="btn btn-primary">Sign Up</button></a></center>';
        }
    }else{
        echo $this->session->set_flashdata('msg','Username or Password is Wrong');
        redirect('welcome/login');
    }
  }





  function logout(){
      $this->session->sess_destroy();
      redirect('welcome/login');
  }
}
