<?php 

class Mymodel extends CI_Model
{

    function login($user, $pass)
    {

        $this->db->where('admin_name', $user);
        $this->db->where('pass', $pass);
        $this->db->limit(1);
        
        $query = $this->db->get('profile');
        
        if($query->num_rows()==1){
        
        $userdata=$query->row_array();
        return array('status'=>'1','user'=>$userdata);
        
        }
        else{
        
        return false;	
          } 
        }  
        
        function insert_into_database()
	{
		$datestring = ' %Y : %m : %d - %h:%i %a';
        $time = time();
        $date = mdate($datestring,$time);

		$track_id = random_string('alnum', 5);
       
		$data = array(
			'sender_name'=>$this->input->post('sender_name'),
			'sender_address'=>$this->input->post('sender_addr'),
			'sender_phone'=>$this->input->post('sender_phone'),
			'reciever_name'=>$this->input->post('reciever_name'),
			'reciever_address'=>$this->input->post('reciever_addr'),
			'reciever_phone'=>$this->input->post('reciever_phone'),
			'reciever_email'=>$this->input->post('reciever_email'),
			'package_weight'=>$this->input->post('package_weight'),
			'shipment_method'=>$this->input->post('shipment_method'),
			'country'=>$this->input->post('country'),
			'status'=>$this->input->post('status'),
			'package_type'=>$this->input->post('package_type'),
			'date'=>$this->input->post('date'),
			'time'=>$this->input->post('time'),
			'location'=>$this->input->post('location'),
			'comment'=>$this->input->post('comment'),
			'track_number'=> $track_id,
            'order_date'=> $date,
			
			

			
		);

		if($this->db->insert('package_table', $data))
		{
			 return TRUE;
		}else
		{
			return FALSE;
		}

}

    function update($userid)
	{
		$datestring = ' %Y : %m : %d - %h:%i %a';
        $time = time();
        $date = mdate($datestring,$time);

		
       
		$data = array(
			'sender_name'=>$this->input->post('sender_name'),
			'sender_address'=>$this->input->post('sender_addr'),
			'sender_phone'=>$this->input->post('sender_phone'),
			'reciever_name'=>$this->input->post('reciever_name'),
			'reciever_address'=>$this->input->post('reciever_addr'),
			'reciever_phone'=>$this->input->post('reciever_phone'),
			'reciever_email'=>$this->input->post('reciever_email'),
			'package_weight'=>$this->input->post('package_weight'),
			'shipment_method'=>$this->input->post('shipment_method'),
			'country'=>$this->input->post('country'),
			'status'=>$this->input->post('status'),
			'package_type'=>$this->input->post('package_type'),
			'date'=>$this->input->post('date'),
			'time'=>$this->input->post('time'),
			'location'=>$this->input->post('location'),
			'comment'=>$this->input->post('comment'),
			'track_number'=> $this->input->post('track_id'),
            'order_date'=> $date,
			
			

			
		);

			$this->db->where('id', $userid);
		if($this->db->update('package_table', $data))
		{
			return TRUE;
		}else
		{
			return FALSE;
		}

}



		function userdata($userid)
	{
	$this->db->where('id', $userid);
	$query = $this->db->get('package_table');
	return $query->row_array();
}



function insert_into_quote()
{
    $datestring = '%Y : %m : %d - %h:%i %a';
    $time = time();
    $date = mdate($datestring,$time);

    $data = array(
        'name'=>$this->input->post('name'),
        'email'=>$this->input->post('email'),
        'service'=>$this->input->post('service'),
        'date'=> $date   
    );

    if($this->db->insert('quote', $data))
    {
         return TRUE;
    }else
    {
        return FALSE;
    }

}


function newsletter()
{
    $datestring = '%Y : %m : %d - %h:%i %a';
    $time = time();
    $date = mdate($datestring,$time);

    $data = array(
        
        'email'=>$this->input->post('mail'),
        'date'=> $date   
    );

    if($this->db->insert('newsletter', $data))
    {
         return TRUE;
    }else
    {
        return FALSE;
    }

}

function get_data()
	{ 
		
		$query = $this->db->get('package_table');
		return $query->result_array();
	}



function get_quote()
	{ 
		
		$query = $this->db->get('quote');
		return $query->result_array();
	}


function get_email()
	{ 
		
		$query = $this->db->get('newsletter');
		return $query->result_array();
	}
function admindata()
	{ 
		
		$query = $this->db->get('profile');
		return $query->row_array();
	}




    function profile()	
{


	$admin_data = array(
		
		'country' => $this->input->post('country'),
		'admin_name' => $this->input->post('name'),
		'position' =>$this->input->post('position'),
		'number' => $this->input->post('number'),
		'email' =>$this->input->post('email'),
		'addr' =>$this->input->post('addr'),
		'pass' => $this->input->post('pass'),
		'facebook' =>$this->input->post('facebook'),
		'twitter' => $this->input->post('twitter'),
		'linkedin' => $this->input->post('linkedin'),
        'instagram' => $this->input->post('instagram')
		
	);
	if($this->db->update('profile',$admin_data)){
		return true;
	}else{
		return false;
	}
}

function track($user)
	{ 
$this->db->select('*');
	$this->db->from('package_table');
	$this->db->where('track_number', $user);
    $client = $this->db->get();
	return $client->row_array();

	}


	function delete($del){
	$this->db->where('id', $del);
	if($this->db->delete('package_table')){
		return true; 
	}else{
		return false;
	}
}

	function delete_quote($del){
	$this->db->where('id', $del);
	if($this->db->delete('quote')){
		return true; 
	}else{
		return false;
	}
}


	function delete_newsletter($del){
	$this->db->where('id', $del);
	if($this->db->delete('newsletter')){
		return true; 
	}else{
		return false;
	}
}








}    