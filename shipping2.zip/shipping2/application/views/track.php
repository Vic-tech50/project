
<?php 
if($userfile['track_number'] == null || $userfile['track_number'] == ' '){
   $this->session->set_flashdata('message', 'Not Found');
   redirect('home');
}else{ ?>


<section class="contact-form-area section-bg  pt-115 pb-120 fix"  >
        <div class="container w3-card-12" style = "padding: 50px">
            <div class="row justify-content-end">
                <!-- Contact wrapper -->
                <div class="col-xl-12 col-lg-12">
                    <div class="contact-form-wrapper">
                        <!-- From tittle -->
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Section Tittle -->
                                <div class="section-tittle mb-50">
                                                                                                 <?php 
    if($this->session->flashdata('message')){
        echo "<span style = 'color: red'>". $this->session->flashdata('message')."</span>";
    }

    ?>
                                    <h2>Tracking Details</h2>
                                    <p>Details of <span style=" font-weight: bolder;" class="w3-text-black"><?= $userfile['track_number']; ?></span> </p>
                                </div>
                            </div>
                        </div>


                            


<hr style="color: black">

<div class="row">


   <div class="col-lg-12 col-md-12">
                                    <div class="input-form">
<div class="media contact-info">
                            <!-- <span class="contact-info__icon"><i class="ti-arrow-down"></i></span> -->
                            <div class="media-body">
                                <h2 class = "w3-text-deep-orange" style="text-decoration:">Sender Info</h1>
                            </div>
                        </div>
                                    </div>
                                </div>




                                <div class="col-lg-6 col-md-6">
                                    <div class="input-form">
<div class="media contact-info">

                            <div class="media-body">
                                <h5><b><i class="fa  fa-phone-square"></i> Sender name: </b><span style=" padding-left: 15px; font-weight: bolder;" class="w3-text-black"><?= $userfile['sender_name']; ?></span> </h5>
                            </div>
                        </div>
                                    </div>
                                </div>






<div class="col-lg-6 col-md-6">
                                    <div class="input-form">
<div class="media contact-info">

                            <div class="media-body">
                                <h5><b><i class="fa  fa-phone-square"></i> Sender mobile: </b> <span style=" padding-left: 15px; font-weight: bolder;" class="w3-text-black"><?= $userfile['sender_phone']; ?></span> </h5>
                            </div>
                        </div>
                                    </div>
                                </div>



</div>                          

<hr style="color: black">
<div class="row">


   <div class="col-lg-12 col-md-12">
                                    <div class="input-form">
<div class="media contact-info">
                            <!-- <span class="contact-info__icon"><i class="ti-user"></i></span> -->
                            <div class="media-body">
                                <h2 class = "w3-text-deep-orange"style="text-decoration: ">Receiver Info</h2>
                            </div>
                        </div>
                                    </div>
                                </div>


<div class="col-lg-6 col-md-6">
                                    <div class="input-form">
<div class="media contact-info">

                            <div class="media-body">
                                <h5><b><l class = "fa  fa-user"></l> Reciever name: </b> <span style=" padding-left: 15px; font-weight: bolder;" class="w3-text-black"><?= $userfile['reciever_name']; ?></span></h5>
                            </div>
                        </div>
                                    </div>
                                </div>



<div class="col-lg-6 col-md-6">
                                    <div class="input-form">
<div class="media contact-info">

                            <div class="media-body">
                                <h5><b><i class = "fa  fa-phone-square"></i> Reciever phone:</b> <span style=" padding-left: 15px; font-weight: bolder;" class="w3-text-black"><?= $userfile['reciever_phone']; ?></span></h5> 
                            </div>
                        </div>
                                    </div>
                                </div>




<div class="col-lg-12 col-md-12">
                                    <div class="input-form">
<div class="media contact-info">

                            <div class="media-body">
                                <h5><b><i class = "fa   fa-map-marker"></i> Reciever address: </b> <span style=" padding-left: 15px; font-weight: bolder;" class="w3-text-black"><?= $userfile['reciever_address']; ?></span></h5>
                            </div>
                        </div>
                                    </div>
                                </div>


</div>

<hr>
<div class="row">
 

   <div class="col-lg-12 col-md-12">
                                    <div class="input-form">
<div class="media contact-info">
                           <!--  <span class="contact-info__icon"><i class="ti-user"></i></span> -->
                          
                            <div class="media-body">
                                <h2 class = "w3-text-deep-orange"style="text-decoration: ">Package Information</h1>
                            </div>
                            
                        </div>
                                    </div>
                                </div>


<div class="col-lg-6 col-md-6">
                                    <div class="input-form">
<div class="media contact-info">

                            <div class="media-body">
                                <h5><b><i class = "fa fa-asterisk"></i> Package type: </b> <span style=" padding-left: 15px; font-weight: bolder;" class="w3-text-black"><?= $userfile['package_type']; ?></span> </h5>
                            </div>
                        </div>
                                    </div>
                                </div>



<div class="col-lg-6 col-md-6">
                                    <div class="input-form">
<div class="media contact-info">

                            <div class="media-body">
                                <h5><b><i class = "fa fa-asterisk"></i> Package weight: </b> <span style=" padding-left: 15px; font-weight: bolder;" class="w3-text-black"><?= $userfile['package_weight']; ?>KG</span> </h5> 
                            </div>
                        </div>
                                    </div>
                                </div>



<div class="col-lg-6 col-md-6">
                                    <div class="input-form">
<div class="media contact-info">

                            <div class="media-body">
                                <h5><b><i class = "fa   fa-truck"></i> Shipment method: </b> <span style=" padding-left: 15px; font-weight: bolder;" class="w3-text-black"><?= $userfile['shipment_method']; ?></span> </h5>
                            </div>
                        </div>
                                    </div>
                                </div> 




<div class="col-lg-6 col-md-6">
                                    <div class="input-form">
<div class="media contact-info">

                            <div class="media-body">
                                <h5><b><i class = "fa  fa-asterisk"></i> Package status: </b> <span style=" padding-left: 15px; font-weight: bolder;" class="w3-text-black"><?= $userfile['status']; ?></span></h5>
                            </div>
                        </div>
                                    </div>
                                </div>


<div class="col-lg-6 col-md-6">
                                    <div class="input-form">
<div class="media contact-info">

                            <div class="media-body">
                                <h5><b><i class = "fa  fa-calendar"></i> Shipment date: </b> <span style=" padding-left: 15px; font-weight: bolder;" class="w3-text-black"><?= $userfile['date'] . ' / ' .$userfile['time']; ?></span></h5>
                            </div>
                        </div>
                                    </div>
                                </div>



<div class="col-lg-12 col-md-12">
                                    <div class="input-form">
<div class="media contact-info">

                            <div class="media-body">
                                <h5><b><i class = "fa   fa-map-marker"></i> Current Location: </b> <span style=" padding-left: 15px; font-weight: bolder;" class="w3-text-black"><?= $userfile['location']; ?></span></h5>
                            </div>
                        </div>
                                    </div>
                                </div>


<div class="col-lg-12 col-md-12">
                                    <div class="input-form">
<div class="media contact-info">

                            <div class="media-body">
                                <h5><b><i class = "fa  fa-comment"></i> Other Info: </b> <span style=" padding-left: 15px; font-weight: bolder;" class="w3-text-black"><?= $userfile['comment']; ?></span></h5>
                                    
                              
                            </div>
                        </div>
                                    </div>
                                </div>


</div>






                    </div>



                </div>
            </div>
        </div>
    </section>

<?php 
}

?>


