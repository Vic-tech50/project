<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>GT Cargo Logistic - Logistics Company You Can Trust</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <!-- <meta content="Free HTML Templates" name="keywords"> -->
    <meta name="description" content="This is a Trusted Logistics company that provide quick and convenience shipping services worldwide">

    <!-- Favicon -->
    <link href="<?= base_url(); ?>img/gt.jpeg" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?= base_url(); ?>lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?= base_url(); ?>css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url(); ?>w3/w32.css">
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid bg-dark">
        <div class="row py-2 px-lg-5">
            <div class="col-lg-6 text-center text-lg-left mb-2 mb-lg-0">
                <div class="d-inline-flex align-items-center text-white">
                              <center>
<p><div class="dropdown" >
 <div  id="google_translate_element"></div>

                            <script>

                               function googleTranslateElementInit() {

                                  new google.translate.TranslateElement({

                                     pageLanguage: 'en'

                                  }, 'google_translate_element');

                               }

                            </script>

                            <script src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>


</div>
</center>
 
</body>

<style>
.goog-logo-link {
   display:none !important;
}

.goog-te-gadget {
   color: transparent !important;
}

.goog-te-gadget .goog-te-combo {
   color: black !important;
}
</style>
                    <!-- <small><i class="fa fa-phone-alt mr-2"></i>+012 345 6789</small> -->
                    <small class="px-3">|</small>
                    <small><i class="fa fa-envelope mr-2"></i><?= $admindata['email'] ?></small>
                </div>
            </div>
            <div class="col-lg-6 text-center text-lg-right">
                <div class="d-inline-flex align-items-center">
                    <a class="text-white px-2" href="<?= base_url(); ?>">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a class="text-white px-2" href="<?= base_url(); ?>">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a class="text-white px-2" href="<?= base_url(); ?>">
                        <i class="fab fa-linkedin-in"></i>
                    </a>
                    <a class="text-white px-2" href="<?= base_url(); ?>">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a class="text-white pl-2" href="<?= base_url(); ?>">
                        <i class="fab fa-youtube"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-lg-5">
            <a href="<?= base_url(); ?>" class="navbar-brand ml-lg-3">
               <!--  <h1 class="m-0 display-5 text-uppercase text-primary"><i class="fa fa-truck mr-2"></i>Faster</h1> -->
               <img src="<?= base_url()?>img/gt.jpeg" style="width: 100px; height: 50px">
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between px-lg-3" id="navbarCollapse">
                <div class="navbar-nav m-auto py-0">
                    <a href="<?= base_url(); ?>" class=" <?php if($this->uri->segment(1) == '' || $this->uri->segment(1) == 'home')
                    echo 'active ';
                    ?> nav-item nav-link ">Home</a>
                    <a href="<?= site_url('about'); ?>" class=" <?php if($this->uri->segment(1) == 'about')
                    echo 'active ';
                    ?>nav-item nav-link">About</a>
                    <a href="<?= site_url('service'); ?>" class=" <?php if($this->uri->segment(1) == 'service')
                    echo 'active ';
                    ?>nav-item nav-link">Service</a>
                    <a href="mailto: <?= $admindata['email'] ?>"  class=" <?php if($this->uri->segment(1) == 'contact')
                    echo 'active ';
                    ?>nav-item nav-link">Contact</a>
                </div>
                <a href="<?= base_url(); ?>#quote" class="btn btn-primary py-2 px-4 d-none d-lg-block">Get A Quote</a>
            </div>
        </nav>
    </div>
    <!-- Navbar End -->