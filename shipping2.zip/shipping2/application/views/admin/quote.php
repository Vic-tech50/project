<section class="ls with_bottom_border">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-6">
							<ol class="breadcrumb darklinks">
								<li>
									<a href="#">Dashboard</a>
								</li>
								<li class="active">Quote</li>
							</ol>
						</div>
						
					</div>
					<!-- .row -->
				</div>
				<!-- .container -->
			</section>

<section class="ls section_padding_top_50 section_padding_bottom_50 columns_padding_5">
				<div class="container-fluid">
		
	<?php 
    if($this->session->flashdata('message')){
        echo '<div class="alert alert-success w3-zoom">
		<a href="#" class="close" data-dismiss="alert" aria-label="close" style = "color: white">&times;</a>'.
		$this->session->flashdata('message').
	  '</div>';
    }

    ?>
					
					<!-- .row -->

					<div class="row">
						<div class="col-sm-12">
							<div class="with_border with_padding">


								<h3 class="divider_40">Quote</h3>
                                <div class="table-responsive">
<table cellpadding="0" cellspacing="0" border="0" class="striped centered responsive-table table table-striped" id="tab">
            <thead>
              <tr>
              <th>#</th>
                <th>Client name</th>
                <th>Email</th>
                <th>Service</th>
                <th>Date</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
            <?php 
foreach ($getquote as $key => $datagotten) {
  

?>

    <tr>
        <td><?php echo $datagotten['id'];?></td>
         <td><?php echo $datagotten['name'];?></td>
      <td><?php echo $datagotten['email'];?></td>
        <td><?php echo $datagotten['service'];?></td>
        <td><?php echo $datagotten['date'];?></td>
         <td><a href="mailto: <?php echo $datagotten['email'];?>"><button class="btn btn-primary w3-round" type="button">contact</button></a>
         <a href="<?php echo site_url('site/delete_quote/'. $datagotten['id']) ?>"><button class="btn btn-danger w3-round" type="button">delete</button></a>
        </td>
    </tr>

    <?php 
      }

    ?>
            </tbody>
          </table>
    </div>

								
							</div>
							<!-- .with_border -->

						</div>
						<!-- .col-* -->
					</div>
					<!-- .row -->



				</div>
				<!-- .container -->
			</section>














