<section class="ls with_bottom_border">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-6">
							<ol class="breadcrumb darklinks">
								<li>
									<a href="#">Dashboard</a>
								</li>
								<li class="active">Packages</li>
							</ol>
						</div>
						
					</div>
					<!-- .row -->
				</div>
				<!-- .container -->
			</section>
<br><br>
			
	<?php 
    if($this->session->flashdata('message')){
        echo '<div class="alert alert-success w3-zoom">
		<a href="#" class="close" data-dismiss="alert" aria-label="close" style = "color: white">&times;</a>'.
		$this->session->flashdata('message').
	  '</div>';
    }

    ?>
			

<section class="ls section_padding_top_50 section_padding_bottom_50 columns_padding_5">
				<div class="container-fluid">

					
					<!-- .row -->

					<div class="row">
						<div class="col-sm-12">
							<div class="with_border with_padding">


								<h3 class="divider_40">Packages</h3>
                                <div class="table-responsive">
<table cellpadding="0" cellspacing="0" border="0" class="striped centered responsive-table table table-striped" id="tab">
            <thead>
              <tr>
              <th>#</th>
                <th>Date</th>
                <th>Reciever Name</th>
                <th>Reciever Email</th>
                <th>Tracking Number</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
            <?php 
foreach ($getdata as $key => $datagotten) {
  

?>

    <tr>
        <td><?php echo $datagotten['id'];?></td>
         <td><?php echo $datagotten['order_date'];?></td>
      <td><?php echo $datagotten['reciever_name'];?></td>
        <td><?php echo $datagotten['reciever_email'];?></td>
        <td><?php echo $datagotten['track_number'];?></td>
         <td><a href="<?php echo site_url('site/edit/'. $datagotten['id']) ?>"><button class="btn btn-primary w3-round" type="button">edit</button></a>
         <a href="<?php echo site_url('site/delete/'. $datagotten['id']) ?>"><button class="btn btn-danger w3-round" type="button">delete</button></a>
        </td>
    </tr>

    <?php 
      }

    ?>
            </tbody>
          </table>
    </div>

								
							</div>
							<!-- .with_border -->

						</div>
						<!-- .col-* -->
					</div>
					<!-- .row -->



				</div>
				<!-- .container -->
			</section>














