<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->



<head>
<title>GT Cargo Logistic - Logistics Company You Can Trust</title>
	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<![endif]-->
	<meta name="description" content="This is a Trusted Logistics company that provide quick and convenience shipping services worldwide">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href="<?= base_url(); ?>img/gt.jpeg" rel="icon">
	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <link rel="stylesheet" href="<?= base_url(); ?>w3/w32.css">
	<link rel="stylesheet" href="<?= base_url(); ?>admin_folder/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?= base_url(); ?>admin_folder/css/animations.css">
	<link rel="stylesheet" href="<?= base_url(); ?>admin_folder/css/fonts.css">
	<link rel="stylesheet" href="<?= base_url(); ?>admin_folder/css/main.css" class="color-switcher-link">
	<link rel="stylesheet" href="<?= base_url(); ?>admin_folder/css/dashboard.css" class="color-switcher-link">
	<script src="<?= base_url(); ?>admin_folder/js/vendor/modernizr-2.6.2.min.js"></script>

	<!--[if lt IE 9]>
		<script src="js/vendor/html5shiv.min.js"></script>
		<script src="js/vendor/respond.min.js"></script>
		<script src="js/vendor/jquery-1.12.4.min.js"></script>
	<![endif]-->

</head>