<body class="admin">
	<!--[if lt IE 9]>
		<div class="bg-danger text-center">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/" class="highlight">upgrade your browser</a> to improve your experience.</div>
	<![endif]-->

	<div class="preloader">
		<div class="preloader_image"></div>
	</div>



	

	

	<!-- wrappers for visual page editor and boxed version of template -->
	<div id="canvas">
		<div id="box_wrapper">

			<!-- template sections -->
			<section class="ls section_padding_top_100 section_padding_bottom_100 section_full_height">
				<div class="container">
	
					<div class="row">
						<div class="col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4 to_animate">
							<div class="with_border with_padding">
	
								<h4 class="text-center">
									Sign In to Your Account
								</h4>
								<hr class="bottommargin_30">
								<?php 
    if($this->session->flashdata('message')){
        echo '<div class="alert alert-danger w3-zoom">
		<a href="#" class="close" data-dismiss="alert" aria-label="close" style = "color: white">&times;</a>'.
		$this->session->flashdata('message').
	  '</div>';
    }

    ?>
								<div class="wrap-forms">
									<form action = "<?= site_url('verify')?>" method = "post">
										<div class="row">
											<div class="col-sm-12">
												<div class="form-group has-placeholder">
													<label for="user">Username</label>
													<i class="grey fa fa-user"></i>
													<input type="text" class="form-control" id="user" placeholder="Username" name="username" required>
												</div>

											</div>
										</div>
										<div class="row">
											<div class="col-sm-12">
												<div class="form-group has-placeholder">
													<label for="login-password">Password</label>
													<i class="grey fa fa-pencil-square-o"></i>
													<input type="password" class="form-control" id="login-password" placeholder="Password" name ="password" required>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-sm-12">
												<div class="checkbox">
													<input type="checkbox" id="remember_me_checkbox">
													<label for="remember_me_checkbox">Remember Me
													</label>
												</div>
											</div>
										</div>
										<button type="submit" class="theme_button block_button w3-deep-orange">Log In</button>
									</form>
								</div>

								<!-- <div class="darklinks text-center topmargin_20">

									<a role="button" data-toggle="collapse" href="#signin-resend-password" aria-expanded="false" aria-controls="signin-resend-password">
							Forgot your password?
						</a>

								</div>
								<div class="collapse form-inline-button" id="signin-resend-password">
									<form class="form-inline topmargin_20">
										<div class="form-group">
											<label class="sr-only">Enter your e-mail</label>
											<input type="email" class="form-control" placeholder="E-mail">
										</div>
										<button type="submit" class="theme_button with_icon">
											<i class="fa fa-share"></i>
										</button>
									</form>
								</div> -->


							</div>
							<!-- .with_border -->

					<br>
					<center> Click  <a href="<?= site_url('home'); ?>">Here</a> to return to homepage </center>
				</p>

						</div>
						<!-- .col-* -->
					</div>  
					<!-- .row -->
				</div>
				<!-- .container -->
			</section>
		</div>
		<!-- eof #box_wrapper -->
	</div>
	<!-- eof #canvas -->




	


	<!-- template init -->
	<script  src="<?= base_url(); ?>admin_folder/js/compressed.js"></script>
	<script  src="<?= base_url(); ?>admin_folder/js/main.js"></script>

	<!-- dashboard libs -->

	<!-- events calendar -->
	<script  src="<?= base_url(); ?>admin_folder/js/admin/moment.min.js"></script>
	<script  src="<?= base_url(); ?>admin_folder/js/admin/fullcalendar.min.js"></script>
	<!-- range picker -->
	<script  src="<?= base_url(); ?>admin_folder/js/admin/daterangepicker.js"></script>

	<!-- charts -->
	<script  src="<?= base_url(); ?>admin_folder/js/admin/Chart.bundle.min.js"></script>
	<!-- vector map -->
	<script  src="<?= base_url(); ?>admin_folder/js/admin/jquery-jvectormap-2.0.3.min.js"></script>
	<script  src="<?= base_url(); ?>admin_folder/js/admin/jquery-jvectormap-world-mill.js"></script>
	<!-- small charts -->
	<script  src="<?= base_url(); ?>admin_folder/js/admin/jquery.sparkline.min.js"></script>

	<!-- dashboard init -->
	<script  src="<?= base_url(); ?>admin_folder/js/admin.js"></script>

</body>



</html>