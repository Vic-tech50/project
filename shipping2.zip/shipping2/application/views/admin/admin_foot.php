<!-- <section class="page_copyright ds darkblue_bg_color">
				<div class="container-fluid">
					<div class="row">
						<div class="col-sm-6">
							<p class="grey">&copy; Copyrights 2017</p>
						</div>
						<div class="col-sm-6 text-sm-right">
							<p class="grey">Last account activity <i class="fa fa-clock-o"></i> 52 mins ago</p>
						</div>
					</div>
				</div>
			</section> -->

		</div>
		<!-- eof #box_wrapper -->
	</div>
	<!-- eof #canvas -->


	




	<!-- template init -->
	<script  src="<?= base_url(); ?>admin_folder/js/compressed.js"></script>
	<script  src="<?= base_url(); ?>admin_folder/js/main.js"></script>

	<!-- dashboard libs -->

	<!-- events calendar -->
	<script  src="<?= base_url(); ?>admin_folder/js/admin/moment.min.js"></script>
	<script  src="<?= base_url(); ?>admin_folder/js/admin/fullcalendar.min.js"></script>
	<!-- range picker -->
	<script  src="<?= base_url(); ?>admin_folder/js/admin/daterangepicker.js"></script>

	<!-- charts -->
	<script  src="<?= base_url(); ?>admin_folder/js/admin/Chart.bundle.min.js"></script>
	<!-- vector map -->
	<script  src="<?= base_url(); ?>admin_folder/js/admin/jquery-jvectormap-2.0.3.min.js"></script>
	<script  src="<?= base_url(); ?>admin_folder/js/admin/jquery-jvectormap-world-mill.js"></script>
	<!-- small charts -->
	<script  src="<?= base_url(); ?>admin_folder/js/admin/jquery.sparkline.min.js"></script>

	<!-- dashboard init -->
	<script  src="<?= base_url(); ?>admin_folder/js/admin.js"></script>

	<script src="<?= base_url(); ?>datatables/jquery.dataTables.js"></script>   
  <script src="<?= base_url(); ?>datatables/dataTables.bootstrap4.js"></script>
  <script src="<?= base_url(); ?>datatables/dataTables.bootstrap4.min.js"></script>
<script>
    $(document).ready(function(){
        $('#tab').DataTable();
    });
</script>

</body>



</html>