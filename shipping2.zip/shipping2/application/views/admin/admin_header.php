<!DOCTYPE html>

<html class="no-js">




<head>
	<title>GT Cargo Logistic - Logistics Company You Can Trust</title>
	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<![endif]-->
	<meta name="description" content="This is a Trusted Logistics company that provide quick and convenience shipping services worldwide">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<link href="<?= base_url(); ?>img/gt.jpeg" rel="icon">
    <link rel="stylesheet" href="<?= base_url(); ?>w3/w32.css">
	<link rel="stylesheet" href="<?= base_url(); ?>datatables/dataTables.bootstrap4.css">
	<link rel="stylesheet" href="<?= base_url(); ?>admin_folder/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?= base_url(); ?>admin_folder/css/animations.css">
	<link rel="stylesheet" href="<?= base_url(); ?>admin_folder/css/fonts.css">
	<link rel="stylesheet" href="<?= base_url(); ?>admin_folder/css/main.css" class="color-switcher-link">
	<link rel="stylesheet" href="<?= base_url(); ?>admin_folder/css/dashboard.css" class="color-switcher-link">
	<script src="<?= base_url(); ?>admin_folder/js/vendor/modernizr-2.6.2.min.js"></script>


</head>

<body class="admin">
	<!--[if lt IE 9]>
		<div class="bg-danger text-center">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/" class="highlight">upgrade your browser</a> to improve your experience.</div>
	<![endif]-->

    



	

	

	<!-- wrappers for visual page editor and boxed version of template -->
	<div id="canvas">
		<div id="box_wrapper">

			<!-- template sections -->

			<header class="page_header_side page_header_side_sticked active-slide-side-header ds">
				<div class="side_header_logo ds ms">
					<a href="<?= site_url('admin_dashboard') ?>">
						<!-- <span class="logo_text margin_0">
							Social
							<strong>Activism</strong>
						</span> -->
						 <img src="<?= base_url()?>img/gt.jpeg" style="width: 100px; height: 50px">
					</a>
				</div>
				<span class="toggle_menu_side toggler_light header-slide">
					<span></span>
				</span>
				<div class="scrollbar-macosx">
					<div class="side_header_inner">

						<!-- user -->

						<div class="user-menu">


							<ul class="menu-click">
								<li>
									<a href="#">
										<div class="media">
											<div class="media-left media-middle">
												<img src="<?= base_url(); ?>img/icon.jpg" alt="">
											</div>
											<div class="media-body media-middle">
												<h4><?= $admindata['admin_name'] ?></h4>
												<?= $admindata['position'] ?>

											</div>

										</div>
									</a>
									<ul>
										
										<li>
											<a href="<?= site_url('profile')?>">
												<i class="fa fa-edit"></i>
												Edit Profile
											</a>
										</li>
									
										<li>
											<a href="<?= site_url('logout')?>">
												<i class="fa fa-sign-out"></i>
												Log Out
											</a>
										</li>
									</ul>
								</li>
							</ul>

						</div>

						<!-- main side nav start -->
						<nav class="mainmenu_side_wrapper">
							<h3 class="dark_bg_color">Dashboard</h3>
							<ul class="menu-click">
								<li>
									<a href="<?= site_url('admin_dashboard')?>">
										<i class="fa fa-th-large"></i>
										packages
									</a>

								</li>
							</ul>

							<ul class="menu-click">
								<li>
									<a href="<?= site_url('add_package')?>">
										<i class="fa fa-plus"></i>
										Add package
									</a>
								</li>
							
							</ul>

							<ul class="menu-click">
								<li>
									<a href="<?= site_url('quote')?>">
										<i class="fa fa-list-alt"></i>
										Quotes
									</a>
								</li>
							
							</ul>

							<ul class="menu-click">
								<li>
									<a href="<?= site_url('newsletter')?>">
										<i class="fa fa-envelope-o"></i>
										newsletter
									</a>
								</li>
							
							</ul>
						</nav>
						<!-- eof main side nav -->

						

					</div>
				</div>
			</header>