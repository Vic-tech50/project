 <!-- Header Start -->
 <div class="jumbotron jumbotron-fluid mb-5">
        <div class="container text-center py-5">
            <h1 class="text-primary mb-4">Safe & Faster</h1>
            <h1 class="text-white display-3 mb-5">Logistics Services</h1>
            <div class="mx-auto" style="width: 100%; max-width: 600px;">
            <form action="<?= site_url('track')?>" method = "post">
                                     <?php 
    if($this->session->flashdata('message')){
        echo '<div class="alert alert-danger w3-zoom">
        <a href="#" class="close" data-dismiss="alert" aria-label="close" style = "color: white">&times;</a>'.
        $this->session->flashdata('message').
      '</div>';
    }

    ?>
                <div class="input-group">
                    <input type="text" name="code" class="form-control border-light" style="padding: 30px;" placeholder="Tracking Id">
                    <div class="input-group-append">
                        <button class="btn btn-primary px-3">Track & Trace</button>
                    </div>
                </div>
</form>
            </div>
        </div>
    </div>
    <!-- Header End -->


    <!-- About Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-5 pb-4 pb-lg-0">
                    <img class="img-fluid w-100"src="<?= base_url(); ?>img/about.jpg" alt="">
                    <div class="bg-primary text-dark text-center p-4">
                        <h3 class="m-0">25+ Years Experience</h3>
                    </div>
                </div>
                <div class="col-lg-7">
                    <h6 class="text-primary text-uppercase font-weight-bold">About Us</h6>
                    <h1 class="mb-4">Trusted & Faster Logistic Service Provider</h1>
                    <p class="mb-4">GT Cargo Logistic makes business flow. As one of the world's leading non-asset-based supply chain management companies, we design and implement idustry-leading solutions in both freight management

Over 42,000 dedicated employees, working in 17 regional clusters around the globe, deliver operational excellence - to provide viable answers to the most challenging supply chain questions.</p>
                    
                </div>
            </div>
        </div>
        <!-- Video Modal -->
        <div class="modal fade" id="videoModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>        
                        <!-- 16:9 aspect ratio -->
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe class="embed-responsive-item"src="<?= base_url(); ?>" id="video"  allowscriptaccess="always" allow="autoplay"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->


     <!--  Quote Request Start -->
     <div class="container-fluid bg-secondary my-5" id = "quote">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-7 py-5 py-lg-0">
                    <h6 class="text-primary text-uppercase font-weight-bold">Get A Quote</h6>
                    <h1 class="mb-4">Request A Free Quote</h1>
                    <p class="mb-4">GT Cargo Logistic presents your services with flexible, convenient and quick layouts.</p>
                    <div class="row">
                        <div class="col-sm-4">
                            <h1 class="text-primary mb-2" data-toggle="counter-up">225</h1>
                            <h6 class="font-weight-bold mb-4">SKilled Experts</h6>
                        </div>
                        <div class="col-sm-4">
                            <h1 class="text-primary mb-2" data-toggle="counter-up">1050</h1>
                            <h6 class="font-weight-bold mb-4">Happy Clients</h6>
                        </div>
                        <div class="col-sm-4">
                            <h1 class="text-primary mb-2" data-toggle="counter-up">2500</h1>
                            <h6 class="font-weight-bold mb-4">Complete Projects</h6>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="bg-primary py-5 px-4 px-sm-5">
                        <form class="py-5" action = "<?= site_url('home')?>" method = "post">
                        <?php 
    if($this->session->flashdata('message2')){
        echo '<div class="alert alert-primary w3-zoom">
		<a href="#" class="close" data-dismiss="alert" aria-label="close" style = "color: white">&times;</a>'.
		$this->session->flashdata('message2').
	  '</div>';
    }

    ?>
                            <div class="form-group">
                                <input type="text" class="form-control border-0 p-4" name = "name" placeholder="Your Name" required="required" />
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control border-0 p-4" name = "email" placeholder="Your Email" required="required" />
                            </div>
                            <div class="form-group">
                                <select class="custom-select border-0 px-4" style="height: 47px;" name = "service" required>
                                    <!-- <option>Select A Service</option> -->
                                    <option value="Air Freight">Air Freight</option>
                                    <option value="Ocean Freight">Ocean Freight</option>
                                    <option value="Land Transport">Land Transport</option>
                                </select>
                            </div>
                            <div>
                                <button class="btn btn-dark btn-block border-0 py-3" type="submit">Get A Quote</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Quote Request Start -->


    <!-- Services Start -->
    <div class="container-fluid pt-5">
        <div class="container">
            <div class="text-center pb-2">
                <h6 class="text-primary text-uppercase font-weight-bold">Our Services</h6>
                <h1 class="mb-4">Best Logistic Services</h1>
            </div>
            <div class="row pb-3">
                <div class="col-lg-4 col-md-4 text-center mb-5">
                    <div class="d-flex align-items-center justify-content-center bg-primary mb-4 p-4">
                        <i class="fa fa-2x fa-plane text-dark pr-3"></i>
                        <h6 class="text-white font-weight-medium m-0">Air Freight</h6>
                    </div>
                    <p>Setting the standard in air freight. Our global network has the power to help businesses grow based on years of experience and influenced by the changing needs of our customers. Our road specialists will ensure operational excellence as well as cost-effective solutions </p>
                    <!-- <a class="border-bottom text-decoration-none" href="">Read More</a> -->
                </div>
                <div class="col-lg-4 col-md-4 text-center mb-5">
                    <div class="d-flex align-items-center justify-content-center bg-primary mb-4 p-4">
                        <i class="fa fa-2x fa-ship text-dark pr-3"></i>
                        <h6 class="text-white font-weight-medium m-0">Ocean Freight</h6>
                    </div>
                    <p>The sea freight service has grown conside rably in recent years. We spend timet to know your processes to deliver goods. the company's relationship with cuxtomers is moving away from purely transactional business to value-added propositions.</p>
                    <!-- <a class="border-bottom text-decoration-none" href="">Read More</a> -->
                </div>
                <div class="col-lg-4 col-md-4 text-center mb-5">
                    <div class="d-flex align-items-center justify-content-center bg-primary mb-4 p-4">
                        <i class="fa fa-2x fa-truck text-dark pr-3"></i>
                        <h6 class="text-white font-weight-medium m-0">Land Transport</h6>
                    </div>
                    <p>GT Cargo Logistic worldwide network is well positioned and qualified to help your company develop efficient and tailor-made domestic and trans-border programs for distributing your goods. Our road specialists will ensure operational excellence as well as cost-effective solutions that meet your needs in terms of transit time</p>
                    <!--<a class="border-bottom text-decoration-none" href="">Read More</a> -->
                </div>
                <!-- <div class="col-lg-3 col-md-6 text-center mb-5">
                    <div class="d-flex align-items-center justify-content-center bg-primary mb-4 p-4">
                        <i class="fa fa-2x fa-store text-dark pr-3"></i>
                        <h6 class="text-white font-weight-medium m-0">Cargo Storage</h6>
                    </div>
                    <p>Diam amet eos at no eos sit lorem, amet rebum ipsum clita stet diam sea est diam</p>
                    <a class="border-bottom text-decoration-none" href="">Read More</a>
                </div> -->
            </div>
        </div>
    </div>
    <!-- Services End -->


    <!-- Features Start -->
    <div class="container-fluid bg-secondary my-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-5">
                    <img class="img-fluid w-100"src="<?= base_url(); ?>img/feature.jpg" alt="">
                </div>
                <div class="col-lg-7 py-5 py-lg-0">
                    <h6 class="text-primary text-uppercase font-weight-bold">Why Choose Us</h6>
                    <h1 class="mb-4">Faster, Safe and Trusted Logistics Services</h1>
                    <p class="mb-4">GT Cargo Logistic makes business flow. As one of the world's leading non-asset-based supply chain management companies, we design and implement idustry-leading solutions in both freight management

Over 42,000 dedicated employees, working in 17 regional clusters around the globe, deliver operational excellence - to provide viable answers to the most challenging supply chain questions./p>
                    <ul class="list-inline">
                        <li><h6><i class="far fa-dot-circle text-primary mr-3"></i>Best In Industry</h6>
                        <li><h6><i class="far fa-dot-circle text-primary mr-3"></i>Emergency Services</h6></li>
                        <li><h6><i class="far fa-dot-circle text-primary mr-3"></i>24/7 Customer Support</h6></li>
                    </ul>
                    <!-- <a href="" class="btn btn-primary mt-3 py-2 px-4">Learn More</a> -->
                </div>
            </div>
        </div>
    </div>
    <!-- Features End -->


  




    <!-- Testimonial Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="text-center pb-2">
                <h6 class="text-primary text-uppercase font-weight-bold">Testimonial</h6>
                <h1 class="mb-4">Our Clients Say</h1>
            </div>
            <div class="owl-carousel testimonial-carousel">
                <div class="position-relative bg-secondary p-4">
                    <i class="fa fa-3x fa-quote-right text-primary position-absolute" style="top: -6px; right: 0;"></i>
                    <div class="d-flex align-items-center mb-3">
                        <img class="img-fluid rounded-circle"src="<?= base_url(); ?>img/testimonial-1.jpg" style="width: 60px; height: 60px;" alt="">
                        <div class="ml-3">
                            <h6 class="font-weight-semi-bold m-0">Jhaon Smith</h6>
                            <small>-Engineer</small>
                        </div>
                    </div>
                    <p class="m-0">I really love the way my goods were delivered to me so quickly, GT Cargo Logistic keep the good work going.</p>
                </div>
                <div class="position-relative bg-secondary p-4">
                    <i class="fa fa-3x fa-quote-right text-primary position-absolute" style="top: -6px; right: 0;"></i>
                    <div class="d-flex align-items-center mb-3">
                        <img class="img-fluid rounded-circle"src="<?= base_url(); ?>img/testimonial-2.jpg" style="width: 60px; height: 60px;" alt="">
                        <div class="ml-3">
                            <h6 class="font-weight-semi-bold m-0">Robert Cool</h6>
                            <small>- Creative Designer</small>
                        </div>
                    </div>
                    <p class="m-0">I've been happy with the services provided by GT Cargo Logistic. Their customer care service is a top-notch</p>
                </div>
                <div class="position-relative bg-secondary p-4">
                    <i class="fa fa-3x fa-quote-right text-primary position-absolute" style="top: -6px; right: 0;"></i>
                    <div class="d-flex align-items-center mb-3">
                        <img class="img-fluid rounded-circle"src="<?= base_url(); ?>img/testimonial-3.jpg" style="width: 60px; height: 60px;" alt="">
                        <div class="ml-3">
                            <h6 class="font-weight-semi-bold m-0">Daniel  </h6>
                            <small>- Plumber</small>
                        </div>
                    </div>
                    <p class="m-0">Happy doing business with this company</p>
                </div>
                <div class="position-relative bg-secondary p-4">
                    <i class="fa fa-3x fa-quote-right text-primary position-absolute" style="top: -6px; right: 0;"></i>
                    <div class="d-flex align-items-center mb-3">
                        <img class="img-fluid rounded-circle"src="<?= base_url(); ?>img/testimonial-4.jpg" style="width: 60px; height: 60px;" alt="">
                        <div class="ml-3">
                            <h6 class="font-weight-semi-bold m-0">Vick</h6>
                            <small>- Developer</small>
                        </div>
                    </div>
                    <p class="m-0">I really appreciate the speed of delivery goods across the globe</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Testimonial End -->


 