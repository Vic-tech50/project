   <!-- Header Start -->
   <div class="jumbotron jumbotron-fluid mb-5">
        <div class="container text-center py-5">
            <h1 class="text-white display-3">Service</h1>
            <div class="d-inline-flex align-items-center text-white">
                <p class="m-0"><a class="text-white" href="">Home</a></p>
                <i class="fa fa-circle px-3"></i>
                <p class="m-0">Service</p>
            </div>
        </div>
    </div>
    <!-- Header End -->

<!-- Services Start -->
  <div class="container-fluid pt-5">
        <div class="container">
            <div class="text-center pb-2">
                <h6 class="text-primary text-uppercase font-weight-bold">Our Services</h6>
                <h1 class="mb-4">Best Logistic Services</h1>
            </div>
            <div class="row pb-3">
                <div class="col-lg-4 col-md-4 text-center mb-5">
                    <div class="d-flex align-items-center justify-content-center bg-primary mb-4 p-4">
                        <i class="fa fa-2x fa-plane text-dark pr-3"></i>
                        <h6 class="text-white font-weight-medium m-0">Air Freight</h6>
                    </div>
                    <p>Setting the standard in air freight. Our global network has the power to help businesses grow based on years of experience and influenced by the changing needs of our customers. Our road specialists will ensure operational excellence as well as cost-effective solutions </p>
                    <!-- <a class="border-bottom text-decoration-none" href="">Read More</a> -->
                </div>
                <div class="col-lg-4 col-md-4 text-center mb-5">
                    <div class="d-flex align-items-center justify-content-center bg-primary mb-4 p-4">
                        <i class="fa fa-2x fa-ship text-dark pr-3"></i>
                        <h6 class="text-white font-weight-medium m-0">Ocean Freight</h6>
                    </div>
                    <p>The sea freight service has grown conside rably in recent years. We spend timet to know your processes to deliver goods. the company's relationship with cuxtomers is moving away from purely transactional business to value-added propositions.</p>
                    <!-- <a class="border-bottom text-decoration-none" href="">Read More</a> -->
                </div>
                <div class="col-lg-4 col-md-4 text-center mb-5">
                    <div class="d-flex align-items-center justify-content-center bg-primary mb-4 p-4">
                        <i class="fa fa-2x fa-truck text-dark pr-3"></i>
                        <h6 class="text-white font-weight-medium m-0">Land Transport</h6>
                    </div>
                    <p>GT Cargo Logistic worldwide network is well positioned and qualified to help your company develop efficient and tailor-made domestic and trans-border programs for distributing your goods. Our road specialists will ensure operational excellence as well as cost-effective solutions that meet your needs in terms of transit time</p>
                    <!--<a class="border-bottom text-decoration-none" href="">Read More</a> -->
                </div>
                <!-- <div class="col-lg-3 col-md-6 text-center mb-5">
                    <div class="d-flex align-items-center justify-content-center bg-primary mb-4 p-4">
                        <i class="fa fa-2x fa-store text-dark pr-3"></i>
                        <h6 class="text-white font-weight-medium m-0">Cargo Storage</h6>
                    </div>
                    <p>Diam amet eos at no eos sit lorem, amet rebum ipsum clita stet diam sea est diam</p>
                    <a class="border-bottom text-decoration-none" href="">Read More</a>
                </div> -->
            </div>
        </div>
    </div>
    <!-- Services End -->


    <!--  Quote Request Start -->
    <div class="container-fluid bg-secondary my-5" id = "quote">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-7 py-5 py-lg-0">
                    <h6 class="text-primary text-uppercase font-weight-bold">Get A Quote</h6>
                    <h1 class="mb-4">Request A Free Quote</h1>
                    <p class="mb-4">Brook presents your services with flexible, convenient and quick layouts.</p>
                    <div class="row">
                        <div class="col-sm-4">
                            <h1 class="text-primary mb-2" data-toggle="counter-up">225</h1>
                            <h6 class="font-weight-bold mb-4">SKilled Experts</h6>
                        </div>
                        <div class="col-sm-4">
                            <h1 class="text-primary mb-2" data-toggle="counter-up">1050</h1>
                            <h6 class="font-weight-bold mb-4">Happy Clients</h6>
                        </div>
                        <div class="col-sm-4">
                            <h1 class="text-primary mb-2" data-toggle="counter-up">2500</h1>
                            <h6 class="font-weight-bold mb-4">Complete Projects</h6>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="bg-primary py-5 px-4 px-sm-5">
                        <form class="py-5" action = "<?= site_url('service')?>" method = "post">
                        <?php 
    if($this->session->flashdata('message')){
        echo '<div class="alert alert-primary w3-zoom">
		<a href="#" class="close" data-dismiss="alert" aria-label="close" style = "color: white">&times;</a>'.
		$this->session->flashdata('message').
	  '</div>';
    }

    ?>
                            <div class="form-group">
                                <input type="text" class="form-control border-0 p-4" name = "name" placeholder="Your Name" required="required" />
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control border-0 p-4" name = "email" placeholder="Your Email" required="required" />
                            </div>
                            <div class="form-group">
                                <select class="custom-select border-0 px-4" style="height: 47px;" name = "service">
                                    <option selected>Select A Service</option>
                                    <option value="Air Freight">Air Freight</option>
                                    <option value="Ocean Freight">Ocean Freight</option>
                                    <option value="Land Transport">Land Transport</option>
                                </select>
                            </div>
                            <div>
                                <button class="btn btn-dark btn-block border-0 py-3" type="submit">Get A Quote</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Quote Request Start -->


    <!-- Testimonial Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="text-center pb-2">
                <h6 class="text-primary text-uppercase font-weight-bold">Testimonial</h6>
                <h1 class="mb-4">Our Clients Say</h1>
            </div>
            <div class="owl-carousel testimonial-carousel">
                <div class="position-relative bg-secondary p-4">
                    <i class="fa fa-3x fa-quote-right text-primary position-absolute" style="top: -6px; right: 0;"></i>
                    <div class="d-flex align-items-center mb-3">
                        <img class="img-fluid rounded-circle" src="<?= base_url()?>img/testimonial-1.jpg" style="width: 60px; height: 60px;" alt="">
                        <div class="ml-3">
                            <h6 class="font-weight-semi-bold m-0">Jhaon Smith</h6>
                            <small>-Engineer</small>
                        </div>
                    </div>
                    <p class="m-0">I really love the way my goods were delivered to me so quickly, GT Cargo Logistic keep the good work going.</p>
                </div>
                <div class="position-relative bg-secondary p-4">
                    <i class="fa fa-3x fa-quote-right text-primary position-absolute" style="top: -6px; right: 0;"></i>
                    <div class="d-flex align-items-center mb-3">
                        <img class="img-fluid rounded-circle" src="<?= base_url()?>img/testimonial-2.jpg" style="width: 60px; height: 60px;" alt="">
                        <div class="ml-3">
                            <h6 class="font-weight-semi-bold m-0">Robert Cool</h6>
                            <small>- Creative Designer</small>
                        </div>
                    </div>
                    <p class="m-0">I've been happy with the services provided by GT Cargo Logistic. Their customer care service is a top-notch</p>
                </div>
                <div class="position-relative bg-secondary p-4">
                    <i class="fa fa-3x fa-quote-right text-primary position-absolute" style="top: -6px; right: 0;"></i>
                    <div class="d-flex align-items-center mb-3">
                        <img class="img-fluid rounded-circle" src="<?= base_url()?>img/testimonial-3.jpg" style="width: 60px; height: 60px;" alt="">
                        <div class="ml-3">
                                  <h6 class="font-weight-semi-bold m-0">Daniel  </h6>
                            <small>- Plumber</small>
                        </div>
                    </div>
                    <p class="m-0">Happy doing business with this company</p>
                </div>
                <div class="position-relative bg-secondary p-4">
                    <i class="fa fa-3x fa-quote-right text-primary position-absolute" style="top: -6px; right: 0;"></i>
                    <div class="d-flex align-items-center mb-3">
                        <img class="img-fluid rounded-circle" src="<?= base_url()?>img/testimonial-4.jpg" style="width: 60px; height: 60px;" alt="">
                        <div class="ml-3">
                          <h6 class="font-weight-semi-bold m-0">Vick</h6>
                            <small>- Developer</small>
                        </div>
                    </div>
                    <p class="m-0">I really appreciate the speed of delivery goods across the globe</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Testimonial End -->