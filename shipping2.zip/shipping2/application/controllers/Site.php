<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Site extends CI_Controller {

	function __construct()
	{
		parent:: __construct();
		
		
	}

	
	public function index()
	{

		if($this->input->post('name'))
		{
			
			if($this->mymodel->insert_into_quote())
			{
				$this->session->set_flashdata('message2', 'Recieved, We shall get back to you shortly');
				

			}else
			{
				$this->session->set_flashdata('message2', 'Something wrong, Try again');
				

			}
			redirect('home#quote');

		}

		$data['admindata'] = $this->mymodel->admindata();
		$this->load->view('head',$data);
        $this->load->view('body');
        $this->load->view('foot');
	}

    public function about()
	{
		$data['admindata'] = $this->mymodel->admindata();
		$this->load->view('head',$data);
        $this->load->view('about');
        $this->load->view('foot');
	}

    public function service()
	{
		if($this->input->post('name'))
		{
			
			if($this->mymodel->insert_into_quote())
			{
				$this->session->set_flashdata('message', 'Recieved, We shall get back to you shortly');
				

			}else
			{
				$this->session->set_flashdata('message', 'Something wrong, Try again');
				

			}
			redirect('service#quote');

		}
		$data['admindata'] = $this->mymodel->admindata();
		$this->load->view('head',$data);
        $this->load->view('service');
        $this->load->view('foot');
	}

    public function contact()
	{
		$data['admindata'] = $this->mymodel->admindata();
		$this->load->view('head',$data);
        $this->load->view('contact');
        $this->load->view('foot');
	}

	function track()
	{
			$user = $this->input->post('code');
			if($user == FALSE ){
		redirect('home');
	
	}else{
		/**/
		$data['userfile'] = $this->mymodel->track($user);
		$data['admindata'] = $this->mymodel->admindata();
		$this->load->view('head',$data);
		$this->load->view('track', $data);
		$this->load->view('foot', $data);
				
	}
		
	
	
	}



	public function login()
	{
		$this->load->view('admin/admin_head');
        $this->load->view('admin/admin_body');
       
	}


function md()
{
	echo md5('gold');
}


	public function Profile()
	{

		$data['admindata'] = $this->mymodel->admindata();
		$this->load->view('admin/admin_header',$data);
		$this->load->view('admin/profile');
        $this->load->view('admin/admin_foot');
       
	}

	public function admin()
	{
		$login = $this->session->userdata('log_in');
		if($login == FALSE){
			redirect('login');
		}

		$data['getdata'] = $this->mymodel->get_data();
		$data['admindata'] = $this->mymodel->admindata();
		$this->load->view('admin/admin_header',$data);
		$this->load->view('admin/packages');
        $this->load->view('admin/admin_foot');
       
	}

	public function quote()
	{
		$login = $this->session->userdata('log_in');
		if($login == FALSE){
			redirect('login');
		}
		$data['admindata'] = $this->mymodel->admindata();
		$data['getquote'] = $this->mymodel->get_quote();
		$this->load->view('admin/admin_header',$data);
		$this->load->view('admin/quote');
        $this->load->view('admin/admin_foot');
       
	}


	public function signup()
	{
		$login = $this->session->userdata('log_in');
		if($login == FALSE){
			redirect('login');
		}
		$data['admindata'] = $this->mymodel->admindata();
		$data['getemail'] = $this->mymodel->get_email();
		$this->load->view('admin/admin_header',$data);
		$this->load->view('admin/newsletter');
        $this->load->view('admin/admin_foot');
       
	}

	public function add_package()
	{
		$login = $this->session->userdata('log_in');
		if($login == FALSE){
			redirect('login');
		}
		if($this->input->post('sender_name'))
		{
			
			if($this->mymodel->insert_into_database())
			{
				$this->session->set_flashdata('message', 'Package Added Successfully');
				redirect('admin_dashboard');

			}else
			{
				$this->session->set_flashdata('message', 'Package not Added');
				redirect('add_package');

			}



			 
		}
		$data['admindata'] = $this->mymodel->admindata();
		$this->load->view('admin/admin_header',$data);
		$this->load->view('admin/add_package');
        $this->load->view('admin/admin_foot');
       
	}



		public function edit()
	{
		$login = $this->session->userdata('log_in');
		if($login == FALSE){
			redirect('login');
		}
			$userid = $this->uri->segment(3);

		if($this->input->post('sender_name'))
		{
			if($this->mymodel->update($userid))
			{
				$this->session->set_flashdata('message', 'Updated Successfully');
				
				redirect('admin_dashboard');
			}else
			{
				$this->session->set_flashdata('message', 'Not Updated Successfully, Try Again');
				redirect('edit');


			}

			


			 
		}
		$data['admindata'] = $this->mymodel->admindata();
		$data['fileuser'] = $this->mymodel->userdata($userid);
		$this->load->view('admin/admin_header',$data);
		$this->load->view('admin/edit');
        $this->load->view('admin/admin_foot');
       
	}



	function login_verify()
       {

       	$user  =  $this->input->post('username');
       	$pass =  $this->input->post('password');

       	$check = $this->mymodel->login($user, $pass);
       	if($check['status']  ==  1)
       	{
       		$user = $check['user'];
       		$this->session->set_userdata('log_in', $user);
       		redirect('admin_dashboard');
       	}else
       	{
       		$this->session->set_flashdata('message', 'Username and Password do not match');
       		redirect('login');
       	}


       }

	   function logout(){
		$this->session->sess_destroy();
		redirect('login');
	}	 

	#####################################################################################

	function edit_profile()
{

  if($this->input->post('country'))
  { 
   if($this->mymodel->profile())
   {
    $this->session->set_flashdata('message', "Profile Updated Successfully");
   }
  }else{
   $this->session->set_flashdata('message', "Something wrong. Try again");
  }
  redirect('profile');
}

function newsletter()
{
	{
			
		if($this->mymodel->newsletter())
		{
			$this->session->set_flashdata('mess', 'Signup Successfully');
			

		}else
		{
			$this->session->set_flashdata('mess', 'Signup not successful, try again');
			

		}

		redirect('home#footer');

		
	}
}


	function delete(){
		$del = $this->uri->segment(3);
		if($this->mymodel->delete($del)){
			$this->session->set_flashdata('message', 'deleted successfully');
			}else{
				$this->session->set_flashdata('message', ' not deleted successfully');
			
		}
		redirect('admin_dashboard');
	}

	function delete_quote(){
		$del = $this->uri->segment(3);
		if($this->mymodel->delete_quote($del)){
			$this->session->set_flashdata('message', 'deleted successfully');
			}else{
				$this->session->set_flashdata('message', ' not deleted successfully');
			
		}
		redirect('quote');
	}

function delete_newsletter(){
		$del = $this->uri->segment(3);
		if($this->mymodel->delete_newsletter($del)){
			$this->session->set_flashdata('message', 'deleted successfully');
			}else{
				$this->session->set_flashdata('message', ' not deleted successfully');
			
		}
		redirect('newsletter');
	}







}